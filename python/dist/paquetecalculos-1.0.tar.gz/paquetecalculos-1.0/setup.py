from setuptools import setup

setup(
    
    name="paquetecalculos",
    version="1.0",
    description="paquete de redondea",
    author="juan",
    author_email="jbgb_1999@hotmail.com",
    packages=["paquetecalculos","paquetecalculos.potenciasyreondeos"]
    
    
)