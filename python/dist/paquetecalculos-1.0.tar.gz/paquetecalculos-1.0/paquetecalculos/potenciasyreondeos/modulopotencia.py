def potencia(base,potencia):
    print("la potencia es: ",base**potencia )